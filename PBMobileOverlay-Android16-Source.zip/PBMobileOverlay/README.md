# PBMobile Overlay (Android 16)

A starter Android Studio project for draggable visual overlay controls and a customizable crosshair.

## Features
- Draggable floating SNIPER and SHOTGUN visual buttons.
- Delay setting (50–1000 ms) saved as a visual/metronome preference; it does not automate game input.
- Crosshair shape, color, size, and opacity settings.
- Android overlay permission and foreground service notification.

## Build
1. Open this folder in Android Studio (a recent version supporting API 36).
2. Allow Gradle sync and install the Android 36 SDK platform if prompted.
3. Build > Build APK(s).
4. Install the generated debug APK on the Android 16 device.
5. Open the app, grant "Display over other apps", then tap "Simpan & tampilkan overlay".

The floating controls are visual markers only. They do not inject taps, fire, switch weapons, or automate gameplay. The project is a starter scaffold and has not been compiled or device-tested in this environment. Android may impose additional foreground-service or overlay restrictions depending on device/vendor policy.
