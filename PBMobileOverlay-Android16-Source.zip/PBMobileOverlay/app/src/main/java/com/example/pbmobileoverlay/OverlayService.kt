package com.example.pbmobileoverlay

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val channelId = "pb_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "PBMobile Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("PBMobile Overlay aktif")
                .setContentText("Kontrol visual dan crosshair sedang ditampilkan")
                .setSmallIcon(android.R.drawable.ic_menu_compass).build()
        else Notification.Builder(this).setContentTitle("PBMobile Overlay aktif")
            .setSmallIcon(android.R.drawable.ic_menu_compass).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, notification)
        addFloatingButton("SNIPER", 40, 240, 0xFF245AA5.toInt())
        addFloatingButton("SHOTGUN", 40, 320, 0xFF805323.toInt())
        addCrosshair()
    }

    private fun params(x: Int, y: Int, gravity: Int = Gravity.TOP or Gravity.START) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity; this.x = x; this.y = y }

    private fun addFloatingButton(title: String, x: Int, y: Int, color: Int) {
        val button = TextView(this).apply {
            text = title; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(18, 14, 18, 14)
            background = GradientDrawable().apply { setColor(color); cornerRadius = 48f; setStroke(2, Color.WHITE) }
            alpha = 0.92f
            setOnClickListener { text = if (text.toString().endsWith(" •")) title else "$title •" }
        }
        val lp = params(x, y)
        attachDrag(button, lp)
        wm.addView(button, lp); views.add(button)
    }

    private fun attachDrag(view: View, lp: WindowManager.LayoutParams) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(v, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); true }
                else -> false
            }
        }
    }

    private fun addCrosshair() {
        val view = CrosshairView(this, prefs.getInt("shape", 0), prefs.getInt("color", 0), prefs.getInt("size", 18), prefs.getInt("alpha", 90))
        val lp = params(0, 0, Gravity.CENTER)
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.addView(view, lp); views.add(view)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; views.clear(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

private class CrosshairView(context: Context, private val shape: Int, colorIndex: Int, private val size: Int, alphaPercent: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = listOf(0xFF39FF14, 0xFFFF3333, 0xFFFFFFFF, 0xFF00E5FF, 0xFFFFFF00).getOrElse(colorIndex) { 0xFF39FF14 }.toInt()
        alpha = (alphaPercent.coerceIn(0, 100) * 255 / 100)
        strokeWidth = 3f; style = Paint.Style.STROKE
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = size.toFloat()
        when (shape) {
            1 -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f, paint) }
            2 -> { paint.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, r, paint) }
            3 -> { canvas.drawLine(cx-r, cy, cx+r, cy, paint); canvas.drawLine(cx, cy-r, cx, cy+r, paint); paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 2.5f, paint) }
            else -> { canvas.drawLine(cx-r, cy, cx+r, cy, paint); canvas.drawLine(cx, cy-r, cx, cy+r, paint) }
        }
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) { setMeasuredDimension(100, 100) }
}
