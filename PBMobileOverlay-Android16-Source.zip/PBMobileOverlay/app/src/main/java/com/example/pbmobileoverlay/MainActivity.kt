package com.example.pbmobileoverlay

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }
    private lateinit var delayText: TextView
    private lateinit var colorSpinner: Spinner
    private lateinit var shapeSpinner: Spinner
    private lateinit var sizeSeek: SeekBar
    private lateinit var alphaSeek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 24)
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 14, 0, 8)
        }
        root.addView(label("PBMobile Overlay", 25f))
        root.addView(label("Floating visual controls • Android 16"))
        val permission = Button(this).apply { text = "Izinkan tampil di atas aplikasi lain"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this@MainActivity, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
        } }
        root.addView(permission)

        root.addView(label("Delay visual / metronom: 50–1000 ms"))
        val seek = SeekBar(this).apply { max = 950; progress = (prefs.getInt("delay", 200) - 50).coerceIn(0, 950) }
        delayText = label("${seek.progress + 50} ms")
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                delayText.text = "${p + 50} ms"; prefs.edit().putInt("delay", p + 50).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek); root.addView(delayText)

        root.addView(label("Bentuk crosshair"))
        shapeSpinner = spinner(listOf("Plus", "Titik", "Lingkaran", "Plus + titik"), prefs.getInt("shape", 0))
        root.addView(shapeSpinner)
        root.addView(label("Warna crosshair"))
        colorSpinner = spinner(listOf("Hijau", "Merah", "Putih", "Cyan", "Kuning"), prefs.getInt("color", 0))
        root.addView(colorSpinner)
        root.addView(label("Ukuran crosshair"))
        sizeSeek = SeekBar(this).apply { max = 50; progress = prefs.getInt("size", 18) - 10 }
        root.addView(sizeSeek)
        root.addView(label("Transparansi"))
        alphaSeek = SeekBar(this).apply { max = 100; progress = prefs.getInt("alpha", 90) }
        root.addView(alphaSeek)

        val start = Button(this).apply { text = "Simpan & tampilkan overlay"; setOnClickListener {
            prefs.edit().putInt("shape", shapeSpinner.selectedItemPosition)
                .putInt("color", colorSpinner.selectedItemPosition)
                .putInt("size", sizeSeek.progress + 10)
                .putInt("alpha", alphaSeek.progress).apply()
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Aktifkan izin overlay terlebih dahulu", Toast.LENGTH_LONG).show()
            } else {
                val i = Intent(this@MainActivity, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this@MainActivity, "Overlay diaktifkan", Toast.LENGTH_SHORT).show()
            }
        } }
        root.addView(start)
        val stop = Button(this).apply { text = "Matikan overlay"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
        root.addView(stop)
        root.addView(label("Catatan: tombol overlay hanya kontrol visual/pengingat. Tidak mengirim sentuhan, menembak, atau mengganti senjata otomatis.", 13f))
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun spinner(items: List<String>, selected: Int) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected.coerceIn(items.indices))
    }
}
